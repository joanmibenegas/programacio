/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicisnadal;

/**
 *
 * @author joanmi
 */
public class multiploPequeño {
    public static int numeroPequeño(int n){
        int[] divisores = new int[n];
        int resultat = 0;
        for(int b = 0; b<n; b++){
            divisores[b]=b;
        }
        label:
        for(int c = n; c<divisores.length; c++){
            for(int d = n; d<=0; d--){
                if(c%d==0){
                    c -= +1;
                } else if (d==0){
                    resultat = c;
                    break label;
                }
                
            }
           
        }
        return resultat;
        
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        numeroPequeño(20);
    }
    
}
